from django.db import models



class Customer(models.Model):
    name = models.CharField(max_length=30)
    birth_date = models.DateField()
    email=models.EmailField(primary_key=True)
    mobile=models.CharField(max_length=10)


    def __str__(self):
        return self.name

class Transaction(models.Model):
    sendername=models.CharField( max_length=50 )
    recivername=models.CharField( max_length= 100)
    amount=models.IntegerField()

    def __str__(self):
        return self.sendername



