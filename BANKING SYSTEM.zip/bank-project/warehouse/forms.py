from django.forms import ModelForm
from .models  import Transaction

class Transaction(ModelForm):
    class Meta:
        model=Transaction
        fields=['sendername','recivername','amount']
