from django.shortcuts import render, redirect
from .models import Customer
from .forms import Transaction


# Create your views here.
def index(request):
    return render(request, 'warehouse/index.html')


def transaction(request):
    if request.method == 'GET':
        return render(request,'warehouse/transaction.html', {'form':Transaction()})
    else:
        try:
            form=Transaction(request.POST)
            newtransaction =form.save(commit=False)
            newtransaction.save()
            return redirect('success')
        except ValueError:
            return render(request, 'warehouse/transaction.html', {'form': Transaction()})


def customer(request):
    customer = Customer.objects.all
    return render(request, 'warehouse/customer.html', {'customer': customer})


def success(request):
    return render(request, 'warehouse/success.html', {'customer': customer})